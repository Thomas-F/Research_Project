package edu.vcs.chemproject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class PolyBondDatabaseReader {

    private String myPolyatomicName;
    private String myElementSymbol;
    private boolean isLoadSuccessful = false;
    public ArrayList<String> combinations = new ArrayList<String>();

    PolyBondElement polyBondElement = new PolyBondElement();
    PolyIon polyIon = new PolyIon();

    public PolyBondDatabaseReader() {
    }

    public PolyBondDatabaseReader(String polyatomicName, String elementSymbol) {
        myPolyatomicName = polyatomicName;
        myElementSymbol = elementSymbol;
        loadEverything();
    }

    public void loadEverything() {
        try {
            FileReader fr1 = new FileReader("C:\\Akaash\\Java Workspace\\ChemistryResearchProject\\PolyAtomicDatabase.txt");
            BufferedReader br1 = new BufferedReader(fr1);
            FileReader fr2 = new FileReader("C:\\Akaash\\Java Workspace\\ChemistryResearchProject\\ElementDatabaseForPolyAtomicBonds.txt");
            BufferedReader br2 = new BufferedReader(fr2);
            String theLine = "";

            while ((theLine = br1.readLine()) != null) {
                String[] lineParts = theLine.split(",");
                String name = lineParts[0];

                if (myPolyatomicName.equals(name)) {
                    polyIon = new PolyIon(lineParts[0], lineParts[1], Integer.parseInt(lineParts[2]), lineParts[3]);
                }
            }

            while ((theLine = br2.readLine()) != null) {
                String[] lineParts = theLine.split(",");
                String symbol = lineParts[1];

                int[] oxStates = new int[lineParts.length - 4];
                for (int i = 4; i < lineParts.length; i++) {
                    oxStates[i - 4] = Integer.parseInt(lineParts[i]);
                }

                if (myElementSymbol.equals(symbol)) {
                    polyBondElement = new PolyBondElement(lineParts[0], lineParts[1], Integer.parseInt(lineParts[2]), Double.parseDouble(lineParts[3]), oxStates);
                }
            }
            if (myPolyatomicName.equals(polyIon.getName()) && myElementSymbol.equals(polyBondElement.getSymbol())) {
                isLoadSuccessful = true;

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void compoundMaker() {
        if (isLoadSuccessful == true) {
            int[] oxStateElement = polyBondElement.getOxidationNumbers();
            String symbolElement = polyBondElement.getSymbol();
            int ionicState = polyIon.getOxidationNumbers();
            String symbolPolyIon = polyIon.getRevisedSymbol();

            if (symbolElement == symbolPolyIon) {
                System.out.println("Please run the program again. You cannot bond two polyatomic ions together.");
            } else {
                System.out.print("The possible bond(s) that the two elements can form is(are): ");
                for (int i = 0; i < oxStateElement.length; i++) {
                    if (ionicState > 0 && oxStateElement[i] < 0) {
                        if (Math.abs(ionicState) == Math.abs(oxStateElement[i])) {
                            if (!combinations.contains(symbolPolyIon + " " + symbolElement)) {
                                combinations.add(symbolPolyIon + " " + symbolElement);
                            }
                        } else if ((Math.abs(ionicState) % 2 == 0) && (Math.abs(oxStateElement[i]) % 2 == 0)) {
                            int halfOxStateUno = (Math.abs(ionicState) / 2);
                            int halfOxStateDos = (Math.abs(oxStateElement[i]) / 2);
                            if (!combinations.contains(symbolPolyIon + halfOxStateDos + " " + symbolElement + halfOxStateUno)) {
                                combinations.add(symbolPolyIon + halfOxStateDos + " " + symbolElement + halfOxStateUno);
                            }
                        } else if (Math.abs(oxStateElement[i]) == 1) {
                            if (!combinations.contains(symbolPolyIon + symbolElement + Math.abs(ionicState))) {
                                combinations.add(symbolPolyIon + " " + symbolElement + Math.abs(ionicState));
                            }
                        } else if (Math.abs(ionicState) == 1) {
                            if (!combinations.contains(symbolPolyIon + Math.abs(oxStateElement[i]) + " " + symbolElement)) {
                                combinations.add(symbolPolyIon + Math.abs(oxStateElement[i]) + " " + symbolElement);
                            }
                        } else {
                            if (!combinations.contains(symbolPolyIon + Math.abs(oxStateElement[i]) + " " + symbolElement + Math.abs(ionicState))) {
                                combinations.add(symbolPolyIon + Math.abs(oxStateElement[i]) + " " + symbolElement + Math.abs(ionicState));
                            }
                        }
                    } else if (ionicState < 0 && oxStateElement[i] > 0) {
                        if (Math.abs(ionicState) == Math.abs(oxStateElement[i])) {
                            if (!combinations.contains(symbolPolyIon + " " + symbolElement)) {
                                combinations.add(symbolPolyIon + " " + symbolElement);
                            }
                        } else if ((Math.abs(ionicState) % 2 == 0) && (Math.abs(oxStateElement[i]) % 2 == 0)) {
                            int halfOxStateUno = (Math.abs(ionicState) / 2);
                            int halfOxStateDos = (Math.abs(oxStateElement[i]) / 2);
                            if (!combinations.contains(symbolPolyIon + halfOxStateDos + " " + symbolElement + halfOxStateUno)) {
                                combinations.add(symbolPolyIon + halfOxStateDos + " " + symbolElement + halfOxStateUno);
                            }
                        } else if (Math.abs(oxStateElement[i]) == 1) {
                            if (!combinations.contains(symbolPolyIon + " " + symbolElement + Math.abs(ionicState))) {
                                combinations.add(symbolPolyIon + " " + symbolElement + Math.abs(ionicState));
                            }
                        } else if (Math.abs(ionicState) == 1) {
                            if (!combinations.contains(symbolPolyIon + Math.abs(oxStateElement[i]) + " " + symbolElement)) {
                                combinations.add(symbolPolyIon + Math.abs(oxStateElement[i]) + " " + symbolElement);
                            }
                        } else {
                            if (!combinations.contains(symbolPolyIon + Math.abs(oxStateElement[i]) + " " + symbolElement + Math.abs(ionicState))) {
                                combinations.add(symbolPolyIon + Math.abs(oxStateElement[i]) + " " + symbolElement + Math.abs(ionicState));
                            }
                        }
                    } else {
                    }
                }
                System.out.println(combinations + ".");
            }
        } else {
        }
    }
}
